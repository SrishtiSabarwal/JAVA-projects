package com.mgielib.entity;

public enum UserType {
	FACULTY,ADMIN,STUDENT,NONFACULTY
}
