package com.mgielib.entity;

public enum EMaterialTypes {
	BOOK,PAPER,JOURNAL,PROJECTS,FACULTY_RESOURCES;
}
