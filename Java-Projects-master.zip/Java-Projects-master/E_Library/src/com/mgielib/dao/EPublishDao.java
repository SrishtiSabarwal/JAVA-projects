package com.mgielib.dao;

import com.mgielib.entity.EPublish;

public interface EPublishDao {

	public int addEPublish(EPublish publish);
}
