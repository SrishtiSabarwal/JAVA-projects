package com.mgielib.dao;

import com.mgielib.entity.EBook;

public interface EBookDao {

	public int addEBook(EBook book);

}
