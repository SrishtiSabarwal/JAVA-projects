package com.mgielib.dao;

import com.mgielib.entity.EProject;

public interface EProjectDao {
	
	public int addEProject(EProject project);

}
