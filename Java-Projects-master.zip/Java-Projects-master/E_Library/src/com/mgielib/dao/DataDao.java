package com.mgielib.dao;

public interface DataDao {


	public int uploadData();
	public int downloadData();

}
