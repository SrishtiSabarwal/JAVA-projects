package com.mgielib.dao;

import com.mgielib.entity.EFacultyResource;

public interface EFacultyResourceDao {

	public int addEFacultyResource(EFacultyResource resource);
}
