package com.medibidz.dao;

import java.util.Set;


public interface CategoryDao
{ 	
	public Set<String> getCategories();
}
