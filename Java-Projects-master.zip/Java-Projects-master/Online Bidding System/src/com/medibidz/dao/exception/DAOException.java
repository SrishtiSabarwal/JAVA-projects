package com.medibidz.dao.exception;

public class DAOException extends RuntimeException {

	public DAOException(String arg0) {
		super(arg0);
	}

}
