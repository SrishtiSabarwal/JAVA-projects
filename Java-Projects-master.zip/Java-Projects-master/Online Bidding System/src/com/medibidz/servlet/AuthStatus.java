package com.medibidz.servlet;

public enum AuthStatus {
VALID,INVALID,UN_AUTHORIZED
}
